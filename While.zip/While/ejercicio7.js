// 7 

let numero = [3, 5, 7, 2, 8, 9, 10, 12, 20, 15];
let i = 1;
function numeroGrande (array) {
    let numeroGrande = 0 
    while (i < numero.length) {
        if (numero[i] > numero[i-1]) {
            numeroGrande = numero[i]
        }
        i++
    }
    return numeroGrande
}
console.log (numeroGrande (numero));