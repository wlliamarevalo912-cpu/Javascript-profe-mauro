//2 

let suma = 0
let i = 0
while (i <= 10) {
    suma += i;
     i++;
    console.log(i + "+" + suma + "=" + (i + suma));
}