//8 

let numero = [3, 5, 7, 2, 8, 9, 10, 12, 15, 20];
let acumulador = 0;
let i = 0;

function promedio() {      
    while (i < numero.lenght) {
        acumulador += numero[i]; 
         i++;  
    }
    let promedio = acumulador / numero.lenght
    return promedio
}
console.log(promedio());